import streamlit as st
import pandas as pd

# --- Title ---
st.title("Pengeluaran anak kos 71251192")


# --- Input Uang Bulanan ---
st.subheader("Uang Bulanan")
uang_bulanan = st.number_input(
    "masukkan uang bulanan:",
    min_value = 0,
    value = 0,
    step = 10000
)


# --- Input Pengeluaran ---
st.subheader("Pengeluaran Bulanan")
makanan = st.number_input(
    "makanan:",
    min_value= 0,
    value=0,
    step=10000
)
kos = st.number_input(
    "kos:",
    min_value= 0,
    value=0,
    step=10000
)
transportasi = st.number_input(
    "transportasi:",
    min_value= 0,
    value=0,
    step=10000
)
internet = st.number_input(
    "internet:",
    min_value= 0,
    value=0,
    step=10000
)
hiburan = st.number_input(
    "hiburan:",
    min_value= 0,
    value=0,
    step=10000
)

# --- Tombol Ngitung Pengeluaran ---
if st.button("hitung pengeluaran"): # if jangan dihapus, cuman nambahin tombol disini :

    # --- Ngitung Total Pengeluaran ---
    total_pengeluaran = (
        makanan + 
        kos +
        transportasi +
        internet +
        hiburan
    )

    # --- Ngitung Sisa Uang ---
    sisa_uang = uang_bulanan - total_pengeluaran

    kolom1, kolom2, kolom3 = st.columns(3)

    # --- Menampilkan Hasil Perhitungan ---
    st.subheader("Ringkasan Keuangan")
    kolom1, kolom2, kolom3 = st.columns(3)
    with kolom1:
        st.metric(
            # Tampilin uang bulanan di sini
            "uang_bulanan", f"Rp{uang_bulanan:,.0F}"
        )
    with kolom2:
        st.metric(
            # Tampilin total pengeluaran di sini
            "total_pengeluaran", f"Rp{total_pengeluaran:,.0F}"
        )
    with kolom3:
        st.metric(
            # Tampilin sisa uang di sini
            "sisa_uang", f"Rp{sisa_uang:,.0F}"
        )


    # --- Kondisi Keuangan ---
    st.subheader("Kondisi Keuangan")

    # Kondisi 1
    if sisa_uang > 0:
        st.success("Keuanganmu masih aman")

    # Kondisi 2
    elif sisa_uang == 0 :
        st.warning("Keuanganmu Habis")

    # Kondisi 3
    else:
        st.error("Pengeluaranmu melebihi uang bulanan")


    # --- Data Pengeluaran ---
    # Ini gausah diubah! 
    # Udah kubantu bikinin, tinggal dipake aja
    data_pengeluaran = {
        "Kategori": [
            "Makanan",
            "Kos",
            "Transportasi",
            "Internet/Pulsa",
            "Hiburan"
        ],
        "Pengeluaran": [
            makanan,
            kos,
            transportasi,
            internet,
            hiburan
        ]
    }

    df_pengeluaran = pd.DataFrame(data_pengeluaran)

    # --- Pengeluaran Terbesar ---
    pengeluaran_terbesar = [
        ("makanan", makanan),
        ("kos", kos),
        ("transportasi", transportasi),
        ("internet", internet),
        ("hiburan", hiburan)
    ] 
    terbesar = pengeluaran_terbesar[0] 
    for pengeluaran in pengeluaran_terbesar:
        if pengeluaran [1] > terbesar [1]:
            terbesar = pengeluaran 
            # Cari pengeluaran terbesar

    st.subheader("Pengeluaran Terbesar")
    st.write(
        f"Pengeluaran terbesar adalah **{terbesar[0]}"
        f"terbesar **Rp {terbesar[1]:,.0f}**"
    ) # Tampilin pengeluaran terbesar di sini


    # --- Grafik Pengeluaran ---
    st.subheader("Grafik Pengeluaran")
    st.bar_chart(
        df_pengeluaran.set_index("Kategori")
    ) # Tampilin grafik pengeluaran di sini